var appId = -1;
var envId = -1;
var version = "";
getSession();

// 提交
$("#item_submit").on("click", function (e) {
    $("#error").addClass("hide");
    var app = $("#app").val();
    var desc = $("#desc").val();
    var emails = $("#emails").val();

    // 验证
    if (!desc || !app) {
        $("#error").removeClass("hide");
        $("#error").html("表单不能为空或填写格式错误！");
        return;
    }
    $.ajax({
        type: "POST",
        url: "/api/app",
        data: {
            "app": app,
            "desc": desc,
            "emails": emails
        }
    }).done(function (data) {
        $("#error").removeClass("hide");
        if (data.success === "true") {
            $("#error").html(data.result);
            layer.confirm("是否继续创建?",{btn:['继续创建','返回首页']},function(){
                $("#app").val('');
                $("#desc").val('');
                $("#emails").val('');
                layer.closeAll();
            },function(){
                window.location.href = "main.html";
            })
        } else {
            Util.input.whiteError($("#error"), data);
        }
    });
});
